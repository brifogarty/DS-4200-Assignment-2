# DS 5500 Assignment: Introduction to HTML/CSS/JS & Local Hosting

This repository is your starting point for the assignment. Your instructions are detailed on [the Google Doc for this assignment](https://docs.google.com/document/d/14SmkKMa0xYu-7OEY4V5jdzglEz63ibbV-n5gbyY3KmM/edit?usp=sharing).

Link to GitHub pages website: XXXXXX